package com.kh.hw.employee.run;

import com.kh.hw.employee.view.EmployeeMenu;

public class Run {

	public static void main(String[] args) {

		EmployeeMenu em = new EmployeeMenu();
		
	}

}




